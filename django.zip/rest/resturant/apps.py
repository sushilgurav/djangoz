from django.apps import AppConfig


class resturantConfig(AppConfig):
    name = 'resturant'

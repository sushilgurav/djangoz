from django.contrib import admin
from .models import rest
# Register your models here.


admin.site.register(rest)

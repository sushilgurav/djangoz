from django.apps import AppConfig


class NameConfig(AppConfig):
    name = 'name'

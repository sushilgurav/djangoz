from django.db import models

# Create your models here.

class author(models.Model):
    author = models.CharField(max_length=100)
    title = models.CharField(max_length=300)
    text = models.CharField(max_length=100)
    created_date = models.CharField(max_length=300)
    published_date = models.CharField(max_length=300)

    def __str__(self):
       return self.author
    def __str__(self):
       return self.title
    def __str__(self):
       return self.text
    def __str__(self):
       return self.created_date

    def __str__(self):
        return self.published_date


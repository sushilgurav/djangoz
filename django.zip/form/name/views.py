from django.shortcuts import render
from django.shortcuts import loader
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from .models import author
import datetime
import re

@csrf_exempt
def superfunc(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('author')
        v2 = request.POST.get('title')
        v3 = request.POST.get('text1')
        v4 = request.POST.get('created_date')
        v5 = request.POST.get('published_date')

        data = author(author=v1,title=v2,text=v3,created_date=v4,published_date=v5)
        data.save()
        # adding the values in a context variable
        context = {
            'author1': v1,
            'author2': v2,
            'author3': v3,
            'author4': v4,
            'author5': v5,
        }
        # getting our showdata template
        template = loader.get_template('name/show.html')

        # returing the template
        return HttpResponse(template.render(context, request))

    else:
        # if post request is not true
        # returing the form template
        template = loader.get_template('name/index.html')
        return HttpResponse(template.render())


def monthsYear(request):
    today = datetime.datetime.now().date()
    time = datetime.datetime.now().time()

    monthsOfYear = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
                        'October', 'November', 'December']
    return render(request, "name/datetime.html",
                     {"today": today, "time": time, "months_of_year": monthsOfYear})


def display(request):
    all = author.objects.all()

    matched = []

    for y in all:
        r = re.findall('^A', y.author)
        s = re.findall('^a', y.author)
        if(r or s):
            matched.append(y)

    context1 = {
        'all':all,
        'matched':matched
    }
    template = loader.get_template('name/display.html')

    return HttpResponse(template.render(context1, request))
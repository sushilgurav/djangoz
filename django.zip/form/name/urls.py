from django.conf.urls import url

from . import views

app_name = 'name'

urlpatterns = [

    url(r'^$', views.superfunc, name='index'),
    url('supergo/', views.superfunc, name='show'),
url('time/', views.monthsYear, name='datetime'),
url('display/', views.display, name='display'),
]
from django.shortcuts import render
from django.http import HttpResponse
import datetime

# Create your views here.
#def hello1(request):
   #today = datetime.datetime.now().date()
   #return render(request, "myhello/hello.html", {"today" : today})


def daysweek(request):
   today = datetime.datetime.now().date()
   now = datetime.datetime.now().strftime('%H:%M:%S')

   daysOfWeek = ['January','February','March','April ','May','June','July','August','September','October','November','December']
   return render(request, "appproject/daysoftheweek.html", {"today": today,"now":now, "days_of_week":
   daysOfWeek})


from django.apps import AppConfig


class TechnoladsResortappConfig(AppConfig):
    name = 'technolads_resortapp'

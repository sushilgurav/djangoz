from django.shortcuts import render
from django.shortcuts import loader
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from .models import Resort
from .models import Dish
from .models import Bill
from .models import ResortReview
import datetime
from django.db.models import Max
#import re

@csrf_exempt
def index(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('v1')
        v2 = request.POST.get('v2')
        v3 = request.POST.get('v3')
        v4 = request.POST.get('v4')
        v5 = request.POST.get('v5')

        context = {
            'author': v1,
            'title': v2,
            'text': v3,
            'created_date': v4,
            'published_date': v5,
            'all': all,

        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/show.html')

        # returing the template
        return HttpResponse(template.render(context, request))

    else:
        # if post request is not true
        # returing the form template

        list1 = Resort.objects.all()
        context = {
            'resorts': list1,
        }
        template = loader.get_template('technolads_resortapp/index.html')
        return HttpResponse(template.render(context,request))

@csrf_exempt
def view(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('res_id')

        al = Resort.objects.all().filter(resortid=v1)[0]
        dishes = Dish.objects.all().filter(resortid=v1)
        context = {
            'val': v1,
            'dishes' : dishes,
            'al' : al,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/view.html')

        # returing the template
        return HttpResponse(template.render(context, request))

    else:
        # if post request is not true
        # returing the form template

        list1 = Resort.objects.all()
        context = {
            'resorts': list1,
        }
        template = loader.get_template('technolads_resortapp/index.html')
        return HttpResponse(template.render(context,request))


@csrf_exempt
def addresort(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('v1')
        v2 = request.POST.get('v2')
        v3 = request.POST.get('v3')
        v4 = request.POST.get('v4')
        v5 = request.POST.get('v5')

        data = Resort(resortname=v1, resortid=v2, resortarea=v3, resortcity=v4, resortrating=v5)
        data.save()
        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts': list1,
            'dishes': list2,
            'bills': list3,
            'review':list4,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/add.html')

        # returing the template
        return HttpResponse(template.render(context,request))

    else:
        # if post request is not true
        # returing the form template
        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts' : list1,
            'dishes' : list2,
            'bills': list3,
            'review':list4,
        }
        template = loader.get_template('technolads_resortapp/add.html')
        return HttpResponse(template.render(context,request))

@csrf_exempt
def adddish(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('v1')
        v2 = request.POST.get('v2')
        v3 = request.POST.get('v3')
        v4 = request.POST.get('v4')


        data = Dish(dishname=v1, dishid=v2, resortid=v3, dishprice=v4)
        data.save()

        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts': list1,
            'dishes': list2,
            'bills': list3,
            'review':list4,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/add.html')

        # returing the template
        return HttpResponse(template.render(context,request))



@csrf_exempt
def billsave(request):
        # if post request came
        uid = request.POST.get('uid')
        resid = request.POST.get('resid')
        resname = request.POST.get('resname')
        froma = request.POST.get('from')
        phone = request.POST.get('phone')
        days = request.POST.get('days')
        tprice = request.POST.get('tprice')
        billdate = datetime.datetime.now().date()
        newbillid=Bill.objects.all().aggregate(Max('billid'))['billid__max']+1;

        data = Bill(uid=uid,resid=resid,resname=resname,froma=froma,phone=phone,days=days,tprice=tprice,billdate=billdate,billid=newbillid)
        data.save()
        # getting our showdata template
        return HttpResponse(uid)


@csrf_exempt
def delbill(request):
        # if post request came
        uid = request.POST.get('uid')
        Bill.objects.all().filter(uid=uid).delete()



        # getting our showdata template
        return HttpResponse(uid)


@csrf_exempt
def review(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('v1')
        v2 = request.POST.get('v2')
        v3 = request.POST.get('v3')
        v4 = request.POST.get('v4')


        data = ResortReview(resortid=v1, username=v2, review=v3, reviewrating=v4)
        data.save()

        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts': list1,
            'dishes': list2,
            'bills': list3,
            'review': list4,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/add.html')

        # returing the template
        return HttpResponse(template.render(context,request))


@csrf_exempt
def viewdish(request):
    # if post request came

        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts': list1,
            'dishes': list2,
            'bills': list3,
            'review':list4,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/viewdish.html')

        # returing the template
        return HttpResponse(template.render(context,request))

@csrf_exempt
def viewreview(request):
    # if post request came
    if request.method == 'POST':

        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts': list1,
            'dishes': list2,
            'bills': list3,
            'review':list4,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/viewreview.html')

        # returing the template
        return HttpResponse(template.render(context,request))

@csrf_exempt
def viewbill(request):
    # if post request came

        list1 = Resort.objects.all()
        list2 = Dish.objects.all()
        list3 = Bill.objects.all()
        list4 = ResortReview.objects.all()

        context = {
            'resorts': list1,
            'dishes': list2,
            'bills': list3,
            'review':list4,
        }
        # getting our showdata template
        template = loader.get_template('technolads_resortapp/viewbill.html')

        # returing the template
        return HttpResponse(template.render(context,request))





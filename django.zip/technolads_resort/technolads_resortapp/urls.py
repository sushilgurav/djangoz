from django.conf.urls import url

from . import views

app_name = 'technolads_resortapp'

urlpatterns = [

    url(r'^$', views.index, name='index'),
    url('add/', views.addresort, name='add'),
    url('addresort/', views.addresort, name='add1'),
    url('adddish/', views.adddish, name='add2'),
    url('review/', views.review, name='add3'),
    url('view/', views.view, name='view'),
    url('^viewdish/', views.viewdish, name='viewdish'),
    url('^viewreview/', views.viewreview, name='hh'),
    url('delbill/', views.delbill, name='hh'),

    url('^viewbill/', views.viewbill, name='hh'),
    url('savebill/', views.billsave, name='view')

]
from django.contrib import admin

# Register your models here.
from .models import Resort
from .models import Dish
from .models import ResortReview


# Register your models here.
admin.site.register(Resort)
admin.site.register(Dish)
admin.site.register(ResortReview)
from django.db import models

# Create your models here.
class Resort(models.Model):
    resortid = models.IntegerField()
    resortname = models.CharField(max_length=300)
    resortarea = models.CharField(max_length=300)
    resortcity = models.CharField(max_length=300)
    resortrating = models.FloatField()
    resortprice = models.FloatField(default=500)

    def __int__(self):
       return self.resortid
    def __str__(self):
       return self.resortname
    def __str__(self):
       return self.resortarea
    def __str__(self):
       return self.resortcity
    def __float__(self):
       return self.resortrating
    def __float__(self):
       return self.resortprice

class Dish(models.Model):
    resortid = models.IntegerField()
    dishid = models.IntegerField()
    dishname = models.CharField(max_length=300)
    dishprice = models.FloatField()

    def __int__(self):
       return self.resortid
    def __int__(self):
       return self.dishid
    def __str__(self):
       return self.dishname
    def __float__(self):
       return self.dishprice

class ResortReview(models.Model):
    resortid = models.IntegerField()
    username = models.CharField(max_length=100)
    review = models.CharField(max_length=300)
    reviewrating = models.FloatField()

    def __int__(self):
       return self.resortid
    def __str__(self):
       return self.username
    def __str__(self):
       return self.review
    def __float__(self):
       return self.reviewrating

class Bill(models.Model):
    billid = models.IntegerField(default=1)
    resname = models.CharField(max_length=100)
    resid = models.CharField(max_length=100)
    uid = models.CharField(max_length=300)
    froma = models.CharField(max_length=300)
    days = models.IntegerField()
    phone = models.CharField(max_length=100)
    billdate = models.CharField(max_length=100,default=" ")
    tprice = models.FloatField()

    def __int__(self):
       return self.days
    def __int__(self):
       return self.billid
    def __str__(self):
       return self.resname
    def __str__(self):
       return self.resid
    def __float__(self):
       return self.tprice
    def __str__(self):
       return self.phone
    def __str__(self):
       return self.froma
    def __str__(self):
       return self.uid
    def __str__(self):
       return self.billdate


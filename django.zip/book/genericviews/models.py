from django.db import models

# Create your models here.

class Product(models.Model):
    # title of the watch
    title = models.CharField(max_length=100)
    # description of the watch
    desc = models.CharField(max_length=300)

    def __str__(self):
       return self.title

    def __str__(self):
       return self.desc
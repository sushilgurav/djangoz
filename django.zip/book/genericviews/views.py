from django.shortcuts import render
from django.views import generic

from .forms import ProductForm
from .models import Product
# Create your views here.
# normal view to handle the entry of the product and store it on the database
def makeentry(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)

        if form.is_valid():
            title = request.POST.get('title', '')
            desc = request.POST.get('desc', '')

        product = Product(title=title, desc=desc)
        product.save()

        form = ProductForm()

        return render(request, 'genericviews/makeentry.html', {'form': form})
    else:
        form = ProductForm()
        return render(request, 'genericviews/makeentry.html', {'form': form})


# generic view to fetch the data then show in a list
class IndexView(generic.ListView):
    # a name to refer to the object_list(to be used in the index.html)
    context_object_name = 'product_list'
    template_name = 'genericviews/index.html'

    def get_queryset(self):
        return Product.objects.all()


# generic view to show the details of a particular object
class DetailsView(generic.DetailView):
    model = Product
    template_name = 'genericviews/detail.html'
